#!/bin/bash
tar -czvf PIT_sudoku_HAMIE_Chakib.tar.gz --exclude=sudoku_db.txt ~/Desktop/PIT_sudoku_HAMIE_Chakib
