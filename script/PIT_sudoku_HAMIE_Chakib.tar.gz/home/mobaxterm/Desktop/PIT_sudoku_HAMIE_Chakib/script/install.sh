#!/bin/sh
echo 'export PATH=$PATH:/home/mobaxterm/Desktop/PIT_sudoku_HAMIE_Chakib/src/' >> ~/.bashrc
